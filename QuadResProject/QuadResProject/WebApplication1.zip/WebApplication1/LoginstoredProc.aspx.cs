﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Data.Odbc;
using System.Data.OleDb;
using System.Configuration;
using System.Web.Security;

namespace WebApplication1
{
    public partial class LoginstoredProc : System.Web.UI.Page
    {
        public object Login1 { get; private set; }

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           
                int EmployeeId = 0;
             
            string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
                using (SqlConnection con = new SqlConnection(constr))
                {
                    using (SqlCommand cmd = new SqlCommand("Validate_User"))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@EmployeeId", Login1.EmployeeId);
                        cmd.Parameters.AddWithValue("@Password", Login1.Password);
                        cmd.Connection = con;
                        con.Open();
                        EmployeeId = Convert.ToInt32(cmd.ExecuteScalar());
                        con.Close();
                    }
                    switch (EmployeeId)
                    {
                        case -1:
                            Login1.FailureText = "Username and/or password is incorrect.";
                            break;
                        
                        default:
                            FormsAuthentication.RedirectFromLoginPage(Login1.UserName, Login1.RememberMeSet);
                            break;
                    }
                }
            }
        }
    }
}