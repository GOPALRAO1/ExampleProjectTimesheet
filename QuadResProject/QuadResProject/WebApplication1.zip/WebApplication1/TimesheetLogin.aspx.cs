﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Data.Odbc;
using System.Data.OleDb;
namespace WebApplication1
{
    public partial class TimesheetLogin : System.Web.UI.Page
    {

        SqlConnection scon;
        SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            scon = new SqlConnection();
            scon.ConnectionString = "Data Source=DESKTOP-61NRV3L\\MYMACHINE;Database=gowthamidb;user id=sa;Password=Gowthami@123";
            scon.Open();

            int count = 0;
            if (TextBox1.Text != "" && TextBox2.Text != "")
            {
                if (Page.IsValid)
                {
                    string insertStmt = String.Format("select count(*) from EmployeeLogin where EmployeeId ='" + TextBox1.Text + "'and Password='" + TextBox2.Text + "'");
                    cmd = new SqlCommand(insertStmt, scon);
                    cmd.ExecuteNonQuery();
                    //SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    //DataTable dt = new DataTable();
                    //sda.Fill(dt);
                    count = Convert.ToInt32(cmd.ExecuteScalar());
                    if(count == 0)
                    {
                        Label1.Text = "Invalid Username";
                    }
                    else
                    {
                        Response.Redirect("HomePage.aspx");
                    }
                    
                    scon.Close();
                    TextBox1.Text = TextBox2.Text="";
                }
            }
            else
            {
                Label1.Text = "TextBox should not be empty";
            }
            
    
            
        }
    }
}