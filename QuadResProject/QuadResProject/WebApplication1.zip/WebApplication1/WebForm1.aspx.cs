﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Data.Odbc;
using System.Data.OleDb;


namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        SqlConnection scon;
        SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {
            TextBox1.Focus();
            scon = new SqlConnection();
            scon.ConnectionString = "Data Source=DESKTOP-61NRV3L\\MYMACHINE;Database=gowthamidb;user id=sa;Password=Gowthami@123";
            scon.Open();
            Response.Write("Connection is" + " " + scon.State + " " + "with Sql Connection");
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                string insertStmt = String.Format("insert into Employee1(EmployeeId,Firstname,Lastname,Password,ConformPassword,Email,Role,Gender,Address) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}')", TextBox1.Text, TextBox2.Text, TextBox3.Text, TextBox4.Text, TextBox5.Text, TextBox9.Text, RadioButtonList1.SelectedItem.Text, DropDownList1.SelectedItem.Text, TextBox8.Text);
                cmd = new SqlCommand(insertStmt, scon);
                cmd.ExecuteNonQuery();
                scon.Close();
                //TextBox1.Text = TextBox2.Text = TextBox3.Text = TextBox4.Text = TextBox5.Text = TextBox9.Text = RadioButtonList1.SelectedItem.Text = DropDownList1.SelectedItem.Text = TextBox8.Text = "";
            }
            else
            {
                Response.Write("Please provide all details gowthami");
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }

        protected void TextBox5_TextChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox8_TextChanged(object sender, EventArgs e)
        {

        }
    }
}